import reflex as rx


STYLESHEET = [
    "https://fonts.googleapis.com/css?family=Poppins&display=swap",
]